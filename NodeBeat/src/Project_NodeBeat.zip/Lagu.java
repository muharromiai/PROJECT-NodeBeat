//Node untuk lagu, tambahin kalo ada yg kurang

public class Lagu{
    String judul;
    String artist;
    int durasi;

    public Lagu(String judul, String asrtist, int duration){
        this.judul = judul;
        this.artist = artist;
        this.durasi = durasi;
    }
}