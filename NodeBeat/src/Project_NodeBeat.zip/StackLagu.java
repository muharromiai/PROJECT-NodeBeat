public class StackLagu {
    
}
